
import 'package:flutter/widgets.dart';

const Color mainBackgroundColor = Color(0xfff1f3f6);
const Color mainTextTitleColor = Color(0xff366471);
const Color mainTextNormalColor = Color(0xff3e6a77);
const Color mainTextSubColor = Color(0xff6c909b);
const Color mainShadowColor = Color(0x4d3754AA);
